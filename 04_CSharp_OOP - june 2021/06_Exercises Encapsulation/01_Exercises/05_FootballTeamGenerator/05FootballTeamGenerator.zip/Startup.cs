﻿namespace _05FootballTeamGenerator
{
    class Startup
    {
        static void Main()
        {
            Engine.Start();
        }
    }
}
