﻿namespace _04PizzaCalories
{
    class Startup
    {
        static void Main()
        {
            Engine.Start();
        }
    }
}
