﻿namespace _01.ClassBoxData
{
    class Startup
    {
        static void Main()
        {
            Engine.NewBox();
        }
    }
}
