﻿namespace BirthdayCelebrations.Contracts
{
    public interface IMammal
    {
        string Name { get; }

        string Birthdate { get; }
    }
}
