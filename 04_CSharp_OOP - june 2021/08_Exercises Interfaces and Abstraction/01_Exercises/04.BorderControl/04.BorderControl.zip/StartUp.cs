﻿namespace _04.BorderControl
{
    using _04.BorderControl.Core;

    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
