﻿namespace _03.Telephony.Contracts
{
    using System;

    public interface IBrowsable
    {
        string Browse(string site);
    }
}
