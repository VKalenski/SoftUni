﻿namespace MilitaryElite.Enumerations
{
    public enum State
    {
        inProgress,
        Finished
    }
}
