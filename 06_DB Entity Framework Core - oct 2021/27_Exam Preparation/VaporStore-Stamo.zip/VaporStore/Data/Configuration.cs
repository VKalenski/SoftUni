﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=.;Database=VaporStore;Trusted_Connection=True";
			//@"Server=.;Database=VaporStore;User Id=sa;Password=SoftUn!2021;";
	}
}